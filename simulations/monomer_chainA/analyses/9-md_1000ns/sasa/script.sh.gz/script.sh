$path_gmx make_ndx -f ../sim_prot_MG.tpr -o index_cat.ndx


> ri 73


 14 r_73                :    17 atoms

> ri 170


 15 r_170               :    20 atoms

> ri 172


 16 r_172               :    17 atoms

> ri 194


 17 r_194               :    17 atoms

> ri 329


 18 r_329               :    17 atoms

> ri 331


 19 r_331               :    22 atoms

> ri 356


 20 r_356               :    21 atoms

> ri 360


 21 r_360               :    14 atoms

> ri 361


 22 r_361               :    11 atoms

> ri 384


 23 r_384               :    19 atoms


> 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23


gmx_mpi sasa -f ../traj_centered_prot_MG.xtc -n index_cat.ndx -s ../sim_prot_MG.tpr -o sasa.xvg -or sasa_res.xvg -surface -output <<eof
1
14
15
16
17
18
19
20
21
22
23
24
1
eof
