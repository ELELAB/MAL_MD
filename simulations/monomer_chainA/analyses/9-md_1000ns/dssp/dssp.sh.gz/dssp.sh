export DSSP=/usr/local/bin/dssp-2.2.8
