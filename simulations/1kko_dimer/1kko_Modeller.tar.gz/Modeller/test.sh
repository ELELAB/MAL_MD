#CREATED BY ELENA PAPALEO elenap@cancer.dk#
#concatenate pdb files with theseus
#theseus can be downloaded from http://www.theseus3d.org/
#it is also in the template dir
cp ../../theseus_x86.tgz .
tar -xvf theseus_x86.tgz
rm theseus_x86.tgz #after checking that the thesues folder is properly extracted
cd theseus_x86/
rm -r -f examples
cp ../1kko_x_fix.B9999*pdb .
./theseus 1kko_x_fix.B9999*.pdb
rm 1kko_x_fix.B9999*pdb #after checking that theseus have run properly
# remove the first lines from the the  theseus_sup.pdb file, so that only MODELs with coordinates are left, and save it as merged_models.pdb which could be use for the clustering
cp theseus_sup.pdb merged_models.pdb
vim merged_models.pdb

# Next step is selection of the best model. It will be done calculating the RMSD of the selected atoms in the models to the initial (crystal) structure.
# Here we select only methionines, beacuse we changed only them, and calculate RMSD for theirs backbone atoms and C-beta i C-gama atoms from
# the side chain because they are common for selenomethionine and methionine.
# Also consider that make_ndx will renumber everything in a so they residue id do not correspond to the one in the pdb file, so extract desired
# atoms from crystal structure, and also from merged_models.pdb so that they are in proper order.

make_ndx -f 1kko_x.pdb -o index_1kko_x.ndx <<eof
r MSE & a N
r MSE & a CA
r MSE & a C 
18 | 19 | 20 
21 | 7
q
eof
#make new pdb file with only backbone atoms
gmx trjconv -f 1kko_x.pdb -s 1kko_x.pdb  -o 1kko_x_BACKBONE.pdb -n index_1kko_x.ndx<<eof
22
eof

#make index for merged_models.pdb with goup with MET backbone atoms and for residues 1-411 (because 412, 413 are missing in crystal str)
make_ndx -f model1.pdb -o index_model1.ndx<<eof
r MET & 4
r 1-411 & 4
q
eof

#make new pdb file with only backbone atoms
gmx trjconv -f merged_models.pdb  -s model1.pdb   -o merged_models_BACKBONE.pdb -n index_model1.ndx<<eof
18
eof

#make new index file which has correct number of atoms; meaning backbone atoms of 411 residues and one group for MSE/MET mainchain.
make_ndx -f 1kko_x_BACKBONE.pdb -o index_final.ndx<<eof
q
eof

#calculate the rmsd matrix aligning on the protein mainchain and calculating the rmds on the methionine mainchain atoms
g_rms -f merged_models.pdb -s 1kko_x_BACKBONE.pdb -o rmsd.xvg -m rmsd_matrix.xpm -n index_final.ndx << eof
0
2
eof 

# In the obtained file, find the model with the smallest RMSD and that is your model!
# In this case it is model 145 with RMSD value: 2.3849187 Ang 

######################
#  NOT USED FOR MAL  #
######################
#clustering - different algorithm could be used in this example linkage
# run the first time only to calculate the average rmsd (in this example approx. 0.0356786 nm)
#g_cluster -f merged_models.pdb -s model1.pdb -dm rmsd_matrix.xpm -o rmsd_clust.xpm -g cluster.log -sz clust_size.xvg -cl clusters.pdb -clid clust_id.xvg -n index.ndx -method gromos -cutoff 0.1 << eof
#1
#20
#eof
# run the second time with the cutoff equal to average rmsd
#g_cluster -f merged_models.pdb -s model1.pdb -dm rmsd_matrix.xpm -o rmsd_clust.xpm -g cluster.log -sz clust_size.xvg -cl clusters.pdb -clid clust_id.xvg -n index.ndx -method gromos -cutoff 0.0356786 << eof
#1
#20
#eof
#remove backupped copies from the first g_cluster run
#rm *.1*
#plot (for example with gnuplot) cluster size over cluster ID to identify the most populated clusters
# a template file for gnuplot is provided as cluster_size_plot.pnl and can be customized
#if you are working in remote you would need the graphical interface to run it
#it is advisable to put a limit to the xaxis to the first 10-20 clusters if there are many more 
#cp ../../templates/cluster_size_plot.pnl .
#xvg2octave clust_size.xvg
#gnuplot cluster_size_plot.pnl
#pdb_split -n 1,2,3 clusters.pdb  # to extract the average structures of the cluster of interest

