#comparative modeling with multiple templates
from modeller import *              # Load standard Modeller classes
from modeller.automodel import *    # Load the automodel class

class MyModel(automodel):
     def select_atoms(self):
        # Select residues 1 and 2 (PDB numbering)
        #return selection(self.residue_range('1:', '2:'))

        # The same thing from chain A (required for multi-chain models):
        # return selection(self.residue_range('1:A', '2:A'))
        
        # Residues 4, 6, 10:
         return selection(self.residues['1:A'], self.residues['184:A'], self.residues['249:A'], self.residues['287:A'], self.residues['327:A'], self.residues['353:A'], self.residues['381:A'], self.residues['383:A'], self.residues['389:A'], self.residues['402:A'], self.residues['412:A'], self.residues['413:A'], self.residues['418:B'], self.residues['1:B'], self.residues['666:B'], self.residues['704:B'], self.residues['744:B'], self.residues['770:B'], self.residues['798:B'], self.residues['800:B'], self.residues['806:B'], self.residues['819:B'], self.residues['829:B'], self.residues['830:B'])
 #          return selection(self)
     def user_after_single_model(self):
        # Report on symmetry violations greater than 1A after building
        # each model:
          self.rename_segments(segment_ids=('A','B'), renumber_residues=[1,1])
        # All residues except 1-5:
        #  return selection(self) - selection(self.residue_range('6:A', '28:A'), self.residue_range('42:A', '63:A'))
     def special_patches(self, aln):
         self.patch(residue_type='DISU', residues=(self.residues['155:A'],self.residues['162:A']))
         self.patch(residue_type='DISU', residues=(self.residues['572:B'],self.residues['579:B']))
env = environ()
# directories for input atom files
env.io.atom_files_directory = ['.', '../atom_files']

env.io.hetatm = env.io.water = True
# selected atoms do not feel the neighborhood
# env.edat.nonbonded_sel_atoms = 2

a = MyModel(env,
            alnfile  = 'xxx.ali', # alignment filename
            knowns   = ('1kkr_x'),     # codes of the templates
            sequence = '1kkr_x_fix')               # code of the target
a.starting_model= 1                 # index of the first model
a.ending_model  = 200                 # index of the last model
                                    # (determines how many models to calculate)
a.make()                            # do the actual comparative modeling
