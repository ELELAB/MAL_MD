#USAGE: to make nice plot from dssp gromacs file.
# 1st: clean the dssp.xpm file by deleting everything until the actual data sequence("~~~~SSCC") and also the comma that comes after the data.
# So, the only things left in the file are lines containing "~~~SS"
# Next this code can be used to transform lines in correct form.
#install.packages("MDplot")


library(MDplot)

MD1_Binput = read.table("dssp_analsys_dt100.B2.xpm", header = FALSE, fill = TRUE)
MD1_Binput$V2 <- NULL
## For some reason the xpm format has the reversed order od lines, so the first line is actually the last residue
## So vi have to reverse the order of lines
MD1_Border<-as.data.frame(MD1_Binput[nrow(MD1_Binput)[1]:1,])

## Now we have to sparate the characters and transpose matrix (Because the load_dssp fucntion wants it that way)
out <- do.call(cbind, apply(MD1_Border, 1, function(x) data.frame(strsplit(as.character(x), ""))))

## Now we select residues we want to plot 
out_hhl <- out[,c(11:50)]

## Now combine characters together in single row
out_hhl_done <- data.frame(apply(out_hhl, 1, paste, collapse=""))

## Write it to file that can be loaded to load_dssp function
write.table (out_hhl_done, file="B2_ss_hhl.txt",  row.names = FALSE, col.names = FALSE, quote = FALSE)

## Finaly ploting secundary structure compozition
setEPS()
postscript("B2_ss_hhl.eps")
dssp(load_dssp("B2_ss_hhl.txt", mdEngine = "GROMACS"), colours = c("red", "orange", "yellow", "green", "cyan", "blue", "navy", "purple"),
     plotType="curves", printLegend = TRUE)
dev.off()

## Now we select residues we want to plot 
out_B5A2 <- out[,c(69:84)]

## Now combine characters together in single row
out_B5A2_done <- data.frame(apply(out_B5A2, 1, paste, collapse=""))

## Write it to file that can be loaded to load_dssp function
write.table (out_B5A2_done, file="B2_ss_B5A2.txt",  row.names = FALSE, col.names = FALSE, quote = FALSE)

## Finaly plotting secondary structure composition
setEPS()
postscript("B2_ss_B5A2.eps")
dssp(load_dssp("B2_ss_B5A2.txt", mdEngine = "GROMACS"), colours = c("red", "orange", "yellow", "green", "cyan", "blue", "navy", "purple"),
     plotType="curves", printLegend = TRUE)
dev.off()


### FOR ALL RESIDUES ####
#out3 <- data.frame(apply(out, 1, paste, collapse=""))
#write.table (out3, file="out3.txt", row.names = FALSE, col.names = FALSE, quote = FALSE)

#pdf(file = "whole_sequence.pdf", width = 6, height = 3)
#dssp(load_dssp("out3.txt", mdEngine = "GROMACS"), colours = c("red", "orange", "yellow", "green", "cyan", "blue", "navy", "purple"),
#      plotType="curves", printLegend = TRUE)
#dev.off()

#pdf(file = "secundary_B5A2.pdf", width = 6, height = 3)
#dssp(load_dssp("out_B5A2.txt", mdEngine = "GROMACS"), colours = c("red", "orange", "yellow", "green", "cyan", "blue", "navy", "purple"), plotType="curves", printLegend = TRUE)
#dev.off()

