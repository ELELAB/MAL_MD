gmx_mpi make_ndx -f ../9-md_1000ns/sim.tpr -o index_distA_distB.ndx <<eof
del 0-20
r 329 
r 12  
r 13  
r 14  
r 15  
r 16  
r 17  
r 18  
r 19  
r 20  
r 21  
r 22  
r 23  
r 24  
r 25  
r 26  
r 27  
r 28  
r 29  
r 30  
r 31  
r 32  
r 33  
r 34  
r 35  
r 36  
r 37  
r 38  
r 39  
r 40  
r 41  
r 42  
r 43  
r 44  
r 45  
r 46  
r 47  
r 48  
r 49  
r 50  
r 51  
r 70  
r 71  
r 72  
r 73  
r 74  
r 75  
r 76  
r 77  
r 78  
r 79  
r 80  
r 81  
r 82  
r 83  
r 84  
r 85  
r 743 
r 426 
r 427 
r 428 
r 429 
r 430 
r 431 
r 432 
r 433 
r 434 
r 435 
r 436 
r 437 
r 438 
r 439 
r 440 
r 441 
r 442 
r 443 
r 444 
r 445 
r 446 
r 447 
r 448 
r 449 
r 450 
r 451 
r 452 
r 453 
r 454 
r 455 
r 456 
r 457 
r 458 
r 459 
r 460 
r 461 
r 462 
r 463 
r 464 
r 465 
r 484 
r 485 
r 486 
r 487 
r 488 
r 489 
r 490 
r 491 
r 492 
r 493 
r 494 
r 495 
r 496 
r 497 
r 498 
r 499 
q
eof

gmx_mpi pairdist -f ../9-md_1000ns/traj_centered.xtc -s ../9-md_1000ns/sim.tpr -n index_distA_distB.ndx -ref -sel -refgrouping res -selgrouping res -o dist_toQ329_A1.xvg <<eof
0
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
eof

gmx_mpi pairdist -f ../9-md_2000ns_2/traj_centered.xtc -s ../9-md_2000ns_2/sim.tpr -n index_distA_distB.ndx -ref -sel -refgrouping res -selgrouping res -o dist_toQ329_A2.xvg <<eof
0
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
eof

gmx_mpi pairdist -f ../9-md_1000ns_3/traj_centered.xtc -s ../9-md_1000ns_3/sim.tpr -n index_distA_distB.ndx -ref -sel -refgrouping res -selgrouping res -o dist_toQ329_A3.xvg <<eof
0
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
eof

gmx_mpi pairdist -f ../9-md_1000ns/traj_centered.xtc -s ../9-md_1000ns/sim.tpr -n index_distA_distB.ndx -ref -sel -refgrouping res -selgrouping res -o dist_toQ329_B1.xvg <<eof
57
58
59
60
61
62
63
64
65
66
67
68
69
70
71
72
73
74
75
76
77
78
79
80
81
82
83
84
85
86
87
88
89
90
91
92
93
94
95
96
97
98
99
100
101
102
103
104
105
106
107
108
109
110
111
112
113
0
eof

gmx_mpi pairdist -f ../9-md_2000ns_2/traj_centered.xtc -s ../9-md_2000ns_2/sim.tpr -n index_distA_distB.ndx -ref -sel -refgrouping res -selgrouping res -o dist_toQ329_B2.xvg <<eof
57
58
59
60
61
62
63
64
65
66
67
68
69
70
71
72
73
74
75
76
77
78
79
80
81
82
83
84
85
86
87
88
89
90
91
92
93
94
95
96
97
98
99
100
101
102
103
104
105
106
107
108
109
110
111
112
113
114
0
eof



gmx_mpi pairdist -f ../9-md_1000ns_3/traj_centered.xtc -s ../9-md_1000ns_3/sim.tpr -n index_distA_distB.ndx -ref -sel -refgrouping res -selgrouping res -o dist_toQ329_B3.xvg <<eof
57
58
59
60
61
62
63
64
65
66
67
68
69
70
71
72
73
74
75
76
77
78
79
80
81
82
83
84
85
86
87
88
89
90
91
92
93
94
95
96
97
98
99
100
101
102
103
104
105
106
107
108
109
110
111
112
113
114
0
eof
