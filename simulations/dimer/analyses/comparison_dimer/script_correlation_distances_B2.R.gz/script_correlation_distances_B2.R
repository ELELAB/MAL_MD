dist = read.table("outputB2.txt", header = TRUE, fill = TRUE)
dist$time <- NULL
dist$time.1 <- NULL
dist
dist1 <- as.matrix(dist)
res <- cor(dist1)
round(res, 2)
library("Hmisc")
res2 <- rcorr(as.matrix(dist1))
res2
res2$r
res2$P
# ++++++++++++++++++++++++++++
# flattenCorrMatrix
# ++++++++++++++++++++++++++++
# cormat : matrix of the correlation coefficients
# pmat : matrix of the correlation p-values
flattenCorrMatrix <- function(cormat, pmat) {
  ut <- upper.tri(cormat)
  data.frame(
    row = rownames(cormat)[row(cormat)[ut]],
    column = rownames(cormat)[col(cormat)[ut]],
    cor  =(cormat)[ut],
    p = pmat[ut]
  )
}
library(Hmisc)
res2<-rcorr(as.matrix(dist1[,1:70]))
flattenCorrMatrix(res2$r, res2$P)
library(corrplot)
setEPS()
postscript("corrplot_B2.eps")
corrplot(res2$r, type="upper", order="hclust",
         p.mat = res2$P, sig.level = 0.01, tl.col = "black", tl.cex = 0.6, insig = "blank")
dev.off()
#View(res2$P)
library("PerformanceAnalytics")
png(file = "corrplot_B2_1.15.distr.png", bg = "transparent")
my_data <- dist1[, c(1:15)]
chart.Correlation(my_data, histogram=TRUE, pch=19)
dev.off()
png(file = "corrplot_B2_16.30.distr.png", bg = "transparent")
my_data <- dist1[, c(16:30)]
chart.Correlation(my_data, histogram=TRUE, pch=19)
dev.off()
png(file = "corrplot_B2_31.45.distr.png", bg = "transparent")
my_data <- dist1[, c(31:45)]
chart.Correlation(my_data, histogram=TRUE, pch=19)
dev.off()
png(file = "corrplot_B2_46.60.distr.png", bg = "transparent")
my_data <- dist1[, c(46:60)]
chart.Correlation(my_data, histogram=TRUE, pch=19)
dev.off()
png(file = "corrplot_B2_60.70.distr.png", bg = "transparent")
my_data <- dist1[, c(60:70)]
chart.Correlation(my_data, histogram=TRUE, pch=19)
dev.off()

library(reshape2)
dist = read.table("outputB2.txt", header = TRUE, fill = TRUE)
rownames(dist) <- 1:nrow(dist)
df.molten <- melt( dist, id.vars="time", value.name="distance", variable.name="residue" )
df.try <- subset(df.molten, residue == "r75" | residue == "r38" | residue == "r49")
setEPS()
postscript("distances_r38.r49.r75.B2.eps")
ggplot(data = df.try, aes(x=time, y=distance, group=residue)) + 
  geom_line(aes(color=residue)) + 
  scale_color_manual(values=c("#ffbf00", "#bf9b30", "#824A02")) + 
  theme_classic() + 
  scale_x_continuous(expand = c(0, 0))
scale_y_continuous(expand = c(1, 0))
dev.off()

